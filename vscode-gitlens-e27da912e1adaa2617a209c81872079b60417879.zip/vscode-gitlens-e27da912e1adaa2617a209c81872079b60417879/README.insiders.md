> **This is the insiders edition of GitLens for early feedback and testing. It works best with [VS Code Insiders](https://code.visualstudio.com/insiders).**
