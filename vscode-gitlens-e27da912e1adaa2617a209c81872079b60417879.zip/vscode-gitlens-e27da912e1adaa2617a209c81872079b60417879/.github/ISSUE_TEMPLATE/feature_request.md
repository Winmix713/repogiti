---
name: Feature request
about: Suggest an idea for GitLens
title: ''
labels: feature, triage
assignees: ''
---

<!-- Describe the feature you'd like. -->
