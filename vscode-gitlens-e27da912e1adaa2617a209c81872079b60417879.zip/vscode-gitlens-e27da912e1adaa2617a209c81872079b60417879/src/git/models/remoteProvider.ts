'use strict';

export interface RemoteProviderReference {
	readonly id: string;
	readonly name: string;
	readonly domain: string;
}
